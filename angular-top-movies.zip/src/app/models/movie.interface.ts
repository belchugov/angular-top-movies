export interface Movie {
    Title: string;
    Poster: string;
    Year: number;
    imdbRating: number;
}
