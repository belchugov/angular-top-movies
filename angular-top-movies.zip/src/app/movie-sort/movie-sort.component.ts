import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movie-sort',
  templateUrl: './movie-sort.component.html',
  styleUrls: ['./movie-sort.component.css']
})
export class MovieSortComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
