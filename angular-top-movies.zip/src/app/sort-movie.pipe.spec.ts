/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SortMoviePipe } from './sort-movie.pipe';

describe('SortMoviePipe', () => {
  it('create an instance', () => {
    let pipe = new SortMoviePipe();
    expect(pipe).toBeTruthy();
  });
});
